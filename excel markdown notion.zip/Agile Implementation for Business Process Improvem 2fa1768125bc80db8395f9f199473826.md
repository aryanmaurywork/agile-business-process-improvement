# Agile Implementation for Business Process Improvement Project

### 1. Problem Statement

The business follows a manual reporting process involving spreadsheets and email communication, resulting in delays, errors, and lack of visibility.

### Business Goal

Improve reporting efficiency, transparency, and predictability using Agile practices.

### Current Challenges

- Reports take ~5 days to complete
- No task ownership clarity
- Frequent rework
- Missed deadlines

### Success Criteria

- Reduce task completion time by at least 15%
- Improve sprint predictability
- Better visibility of work status
1. **Product Backlog**

| Story ID | User Story | Priority | Sprint | Status | Story Points |
| --- | --- | --- | --- | --- | --- |
| US-01 | As a reporting analyst, I want a clear list of reporting tasks so that I know what to work on each day. | High | Sprint 1 |  | 5 points |
| US-02 | As a team lead, I want visibility into task progress so that I can identify blockers early. | High | Sprint 1 |  | 5 points |
| US-03 | As a reviewer, I want reports reviewed in smaller batches so that errors are caught earlier. | Medium | Sprint 3 |  | 8 points |
| US-04 | As a stakeholder, I want predictable delivery timelines so that I can plan decisions. | Medium | Sprint 3 |  | 8 points |

3️⃣ **Sprint Board**

[Sprint 1   ](Sprint%201%202fa1768125bc80e598f5f0740f83a75f.csv)

DAILY STANDUP

**Day 1**

- Yesterday: Backlog created
- Today: Defining reporting tasks
- Blockers: None

**Day 6**

- Yesterday: Task tracking improved
- Today: Final review
- Blockers: Review delays

4️⃣ **Retrospectives**

Sprint 1 Retrospective

**What went well**

- Clear task visibility
- Reduced follow-ups

**What didn’t**

- Initial confusion on priorities

**Action Items**

- Limit WIP
- Add mid-sprint check

5️⃣ **Sprint Metrics**

[Untitled](Untitled%202fa1768125bc808d8f3fd9bc3c644e5c.csv)

Create visibility and ownership of reporting tasks.